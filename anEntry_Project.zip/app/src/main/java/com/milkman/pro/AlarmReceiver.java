package com.milkman.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Scheduler.notify(c, i.getStringExtra("t"), i.getStringExtra("b"));
        Scheduler.scheduleAll(c); // agla alarm laga do
    }
}
